# VOKAMBAKAMBA API 🇿🇲

A REST API serving Zambian language grammar rules.

## Setup

```bash
npm install
npm start
```

For development with auto-restart:
```bash
npm run dev
```

## Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/` | API info & available endpoints |
| GET | `/api/languages` | List all languages |
| GET | `/api/grammar/:lang` | All grammar topics for a language |
| GET | `/api/grammar/:lang/:topic` | Specific grammar topic |

## Example Requests

```
GET /api/languages
GET /api/grammar/bemba
GET /api/grammar/bemba/noun_classes
GET /api/grammar/bemba/verb_conjugation
GET /api/grammar/nyanja/sentence_structure
GET /api/grammar/tonga/noun_classes
```

## Available Languages
- `bemba`
- `nyanja`
- `tonga`

## Available Topics (varies by language)
- `noun_classes`
- `verb_conjugation`
- `sentence_structure`
- `tones`
- `adjectives`

## Deploy to Railway

1. Push this folder to a GitHub repo
2. Go to railway.app → New Project → Deploy from GitHub
3. Select the repo — Railway auto-detects Node.js
4. Done! Railway gives you a public URL

## Adding More Languages

Edit `data/grammar.json` and follow the same structure:

```json
{
  "lozi": {
    "language": "Lozi",
    "code": "loz",
    "region": "Western Province",
    "family": "Bantu",
    "topics": {
      "noun_classes": { ... },
      "verb_conjugation": { ... }
    }
  }
}
```
